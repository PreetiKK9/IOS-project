<div>
<h1>Calculator that will help you calculate tips in the company</>
 </div>
 <img src="https://sun9-north.userapi.com/sun9-81/s/v1/if2/QJ6vcCowBMdZ0YWpvZNALMSAUI8rUj5L1Ytujp5JtzhjwMkkNoMJmcupd2VVAhjKUpRwae9e8KYOWQWwIRF17_wH.jpg?size=828x1792&quality=96&type=album" height="500" align="center"/>
<img src="https://sun9-east.userapi.com/sun9-34/s/v1/if2/9FKjqA7495aWjCDJB8a_pWQVh9ZRcdKgYMaag5q3EP5nzcr5YoT-v9mQI41XqIOXWTxAeMb0n8TjW2GZfjawr8mS.jpg?size=828x1792&quality=96&type=album" height="500" align="center"/>
